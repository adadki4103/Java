package arenaPrototypeB;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.scene.control.ToggleGroup;
import com.jfoenix.controls.JFXRadioButton;
import java.sql.ResultSet;

public class ControllerSupreme implements Initializable{
	

    @FXML
    private ImageView progress; 
    @FXML
    private JFXButton signUpButton;
    @FXML
    private JFXTextField userNameFrontField;
    @FXML
    private JFXPasswordField passwordFrontField;
    @FXML
    private JFXButton signInButton;
     @FXML
    private JFXTextField regUserName;
    @FXML
    private JFXPasswordField regPassword;
    @FXML
    private JFXTextField regEmail;
    @FXML
    private JFXTextField regFName;
    @FXML
    private JFXTextField regLName;
    @FXML
    private JFXButton regSignUpButton;
    @FXML
    private JFXButton regGoBackButton;
    @FXML
    private JFXRadioButton operatorRoleChoice;
    @FXML
    private ToggleGroup roleGroup;
    @FXML
    private JFXRadioButton leagueOwnerRoleChoice;
    @FXML
    private JFXRadioButton playerRoleChoice;
    @FXML
    private JFXRadioButton advertRoleChoice;
    @FXML
    private JFXRadioButton spectatorRoleChoice;

    
    private Connection connection;
    private DBHandler handler;
    private PreparedStatement pst;
    
    
    
    @FXML
    private void handleClose(MouseEvent event){
        System.exit(0);
    }
   
    @FXML
    private void loginAction(MouseEvent e){
        progress.setVisible(true);
        PauseTransition pt = new PauseTransition();
       pt.setDuration(Duration.seconds(3));
       pt.setOnFinished(ev -> 
       { 
        System.out.println("Login Successful!");
    });
              pt.play();
    }
    @FXML
    private void checkIfRegistered(ActionEvent e) throws IOException {
    	// Retrieve Data
    	connection = handler.getConnection();
    	String queryOne = "SELECT * from new_users where newUserName=? and newUserPassword=?";
    	try {
    		pst = connection.prepareStatement(queryOne);
    		pst.setString(1,userNameFrontField.getText());
    		pst.setString(2,passwordFrontField.getText());
    		
    		ResultSet rs = pst.executeQuery();
    		int count = 0;
    		
    		while(rs.next()) {
    			count = count+1;
    		}
    		
    		if(count == 1) {
    			System.out.print("Login Success");
    			
    		       signInButton.getScene().getWindow().hide();
    		       Stage loggedInStage = new Stage();
    		       Parent root = FXMLLoader.load(getClass().getResource("loggedInDefault.fxml"));
    		       Scene scene = new Scene(root);
    		       loggedInStage.setScene(scene);
    		       loggedInStage.initStyle(StageStyle.UNDECORATED);
    		       loggedInStage.setResizable(false);
    		       loggedInStage.show();
    			
    		}
    		else {
    			System.out.println("Username & Password are incorrect.");
    		}
    	}
    	catch(SQLException e3) {
    		e3.printStackTrace();
    	}
    	finally {
    		try {
    		connection.close();
    		}
    		catch(SQLException e4) {
    			e4.printStackTrace();
    		}
    	}
    	
    }
    @FXML 
    private void passDataSignUp(ActionEvent e) throws IOException{
        regSignUpButton.getScene().getWindow().hide();
        Stage mainStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        Scene scene = new Scene(root);
        mainStage.setScene(scene);
        mainStage.initStyle(StageStyle.UNDECORATED);
        mainStage.setResizable(false);
        mainStage.show();
        
              //Saving Data                             1            2               3           4             5           6            7
              String insert = "INSERT INTO new_users(newUserName,newUserPassword,newUserEmail,newUserFName,newUserLname,newUserRole,newUserIDNum)"
                      + "VALUES (?,?,?,?,?,?,?)";
              connection = handler.getConnection();
              try {
              pst = connection.prepareStatement(insert);
              }
              catch(SQLException e1){
                  e1.printStackTrace();
                  System.out.println("SQL ERROR CONTROL SUPREME - e1");
              }
              String roleChoice="";
              
              if(operatorRoleChoice.isSelected()) {
            	  roleChoice = "Operator";
              }
              else if(leagueOwnerRoleChoice.isSelected()) {
            	  roleChoice = "League Owner";
              }
              else if(playerRoleChoice.isSelected()) {
            	  roleChoice = "Player";
              }
              else if(advertRoleChoice.isSelected()) {
            	  roleChoice = "Advertiser";
              }
              else if(spectatorRoleChoice.isSelected()){
            	  roleChoice = "Spectator";
              }
              else{
            	  roleChoice = "No Role!!";
              }
              
              try{
              pst.setString(1, regUserName.getText()); // newUserName
              pst.setString(2, regPassword.getText()); // newUserPassword
              pst.setString(3, regEmail.getText());    // newUserEmail
              pst.setString(4, regFName.getText());    // newUserFName
              pst.setString(5, regLName.getText());    // newUserLName
              pst.setString(6, roleChoice);            // newUserRole
              pst.setInt(7, 0);                        // newUserIDNum
              
              pst.executeUpdate();
              }
              catch(SQLException e2){
                  e2.printStackTrace();
                  System.out.println("SQL ERROR CONTROL SUPREME - e2");
              } 
    }
   
    @FXML
   private void signUpAction(ActionEvent e) throws IOException{
       signUpButton.getScene().getWindow().hide();
       Stage signupStage = new Stage();
       Parent root = FXMLLoader.load(getClass().getResource("signUpPage.fxml"));
       Scene scene = new Scene(root);
       signupStage.setScene(scene);
       signupStage.initStyle(StageStyle.UNDECORATED);
       signupStage.setResizable(false);
       signupStage.show();
   }
   
   @FXML
   private void goBackAction(ActionEvent e) throws IOException{
       regGoBackButton.getScene().getWindow().hide();
       Stage stage = new Stage();
       Parent root = FXMLLoader.load(getClass().getResource("loginPage.fxml"));
       Scene scene = new Scene(root);
       stage.setScene(scene);
       stage.initStyle(StageStyle.UNDECORATED);
       stage.setResizable(false);
       stage.show();
   }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    progress.setVisible(false);
    handler = new DBHandler();
    }    
}
