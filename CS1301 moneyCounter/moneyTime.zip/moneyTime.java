//Author: Adam Adkins
//Student 
//Created: 1/14/2015



import java.util.Scanner;

public class moneyTime  {
  public static void main(String[] args) {
    
   double userInput;
   double currentValue;
  
   int tenDollarBill =0;
   int fiveDollarBill =0;
   int oneDollarBill =0;
   int quarterCent =0;
   int dimeCent =0;
   int nickelCent =0;
   int pennyCent =0 ; 
   
   Scanner obj = new Scanner(System.in);
// Get the user input. Text input gives a run-time error.   
   System.out.println("---Money Organizer---");
   System.out.println("Please enter a monetary value to see it organized by bill & coin.");
   System.out.println("For example: \"42.26\" ");
   userInput = obj.nextDouble();
   
   currentValue = userInput;
   
/* Note: -= is the same as saying currentValue = (currentValue - (tenDollarBill*10)).
 * currentValue is updated after each if-statement. */
   
   if (currentValue >= 10){
     tenDollarBill = (int)currentValue/10;
     currentValue -= (tenDollarBill*10);
   }
//System.out.println(currentValue + " Test Tens");
  
   if (currentValue >= 5){
     fiveDollarBill = (int)currentValue/5;
     currentValue -= (fiveDollarBill * 5);
   }
//System.out.println(currentValue + " Test Fives"); 
  
   if (currentValue >= 1) {
     oneDollarBill =(int)currentValue/1;
     currentValue -=(oneDollarBill);
   }
//System.out.println(currentValue + " Test Ones"); 
  
   if (currentValue >= 0.25){
      quarterCent = (int)((currentValue*100)/25);
      currentValue -=(quarterCent * 0.25);
   }
//System.out.println(currentValue + " Test Quarters"); 
  
   if (currentValue >=0.10){
      dimeCent = (int)((currentValue*100)/10);
      currentValue -=(dimeCent * 0.10);
   }
//System.out.println(currentValue + " Test Dimes"); 
  
   if (currentValue >=0.05){
         nickelCent = (int)((currentValue*100)/5);
         currentValue -=(nickelCent * 0.05);
   }
//System.out.println(currentValue + " Test Nickels");
  
  if (currentValue >=0.01){
    pennyCent = (int)(currentValue*100); 
   } 
//System.out.println(currentValue + " Test Pennies");
  
  
//The results.  
   System.out.println(tenDollarBill + " Ten Dollar Bill(s).");
   System.out.println(fiveDollarBill + " Five Dollar Bill(s).");
   System.out.println(oneDollarBill + " One Dollar Bill(s).");
   System.out.println(quarterCent + " Quarter(s).");
   System.out.println(dimeCent + " Dimes(s).");
   System.out.println(nickelCent + " Nickel(s).");
   System.out.println(pennyCent + " Penny(/ies).");
   
   obj.close();
 
   }
}

